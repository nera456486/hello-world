import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Link, Navigate } from 'react-router-dom';
import LoginForm from './components/LoginForm';
import RegistrationForm from './components/RegistrationForm';
import HomePage from './components/HomePage';
import './styles/global.css';
import './App.css';

function App() {
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [token, setToken] = useState(null);
    const [username, setUsername] = useState(null);
    const [sessionRestored, setSessionRestored] = useState(false);

    const handleLogin = (token, username) => {
        setToken(token);
        setIsLoggedIn(true);
        setUsername(username);
        localStorage.setItem('token', token);
        localStorage.setItem('username', username);
    };

    const handleLogout = () => {
        setToken(null);
        setIsLoggedIn(false);
        setUsername(null);
        localStorage.removeItem('token');
        localStorage.removeItem('username');
    };

    const handleUsernameUpdate = (newUsername) => {
        setUsername(newUsername);
    };

    useEffect(() => {
        console.log("App.js useEffect running");
        const storedToken = localStorage.getItem('token');
        const storedUsername = localStorage.getItem('username');

        console.log("Token from localStorage:", storedToken);
        console.log("Username from localStorage:", storedUsername);

        if (storedToken && storedUsername) {
            setToken(storedToken);
            setIsLoggedIn(true);
            setUsername(storedUsername);
            console.log("Session restored, isLoggedIn:", isLoggedIn, "username:", username);
        } else {
            console.log("No session found in localStorage");
        }
        setSessionRestored(true);
    }, [isLoggedIn, username]);

    if (!sessionRestored) {
        return <div>Загрузка...</div>;
    }

    return (
        <Router>
            <div className="container">
                <nav>
                    <ul>
                        <li>
                            <Link to="/" className="navLink">Главная</Link>
                        </li>
                        {!isLoggedIn && (
                            <>
                                <li>
                                    <Link to="/login" className="navLink">Вход</Link>
                                </li>
                                <li>
                                    <Link to="/register" className="navLink">Регистрация</Link>
                                </li>
                            </>
                        )}
                        {isLoggedIn && (
                            <li>
                                <button onClick={handleLogout}>Выход</button>
                            </li>
                        )}
                    </ul>
                </nav>

                <Routes>
                    <Route path="/login" element={<LoginForm onLogin={handleLogin} />} />
                    <Route path="/register" element={<RegistrationForm />} />
                    <Route
                        path="/"
                        element={
                            isLoggedIn ? (
                                <HomePage
                                    token={token}
                                    username={username}
                                    onUsernameUpdate={handleUsernameUpdate} // Передаем функцию для обновления имени пользователя
                                />
                            ) : (
                                <Navigate to="/login" replace />
                            )
                        }
                    />
                </Routes>
            </div>
        </Router>
    );
}

export default App;