const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');
const cors = require('cors');
const listEndpoints = require('express-list-endpoints');
const app = express();
const port = 3001;

app.use(cors());
app.use(bodyParser.json());

// Обработчик для регистрации
app.post('/register', (req, res) => {
    const { username, email, password } = req.body;

    fs.readFile('data/db.json', 'utf8', (err, data) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Ошибка чтения базы данных');
        }

        const db = JSON.parse(data);

        if (db.users && db.users.find(user => user.username === username)) {
            return res.status(400).send('Имя пользователя уже занято');
        }

        const newUser = {
            id: db.users ? db.users.length + 1 : 1,
            username,
            email,
            password // ВНИМАНИЕ: В РЕАЛЬНОМ ПРИЛОЖЕНИИ ПАРОЛЬ НУЖНО ХЕШИРОВАТЬ!
        };

        db.users = db.users || [];
        db.users.push(newUser);

        fs.writeFile('data/db.json', JSON.stringify(db, null, 2), err => {
            if (err) {
                console.error(err);
                return res.status(500).send('Ошибка записи в базу данных');
            }

            console.log('Новый пользователь зарегистрирован:', newUser);
            res.status(201).json(newUser);
        });
    });
});

// Обработчик для входа
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    fs.readFile('data/db.json', 'utf8', (err, data) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Ошибка чтения базы данных');
        }

        const db = JSON.parse(data);

        const user = db.users && db.users.find(user => user.username === username);

        if (!user || user.password !== password) {
            return res.status(401).send('Неверное имя пользователя или пароль');
        }

        // Вход успешен
        const token = 'ваш_токен'; // Замените на генерацию JWT
        res.json({ token, username: user.username }); // Возвращаем имя пользователя
    });
});

// Обработчик для получения отзывов
app.get('/feedback', (req, res) => {
    fs.readFile('data/db.json', 'utf8', (err, data) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Ошибка чтения базы данных');
        }

        const db = JSON.parse(data);
        res.json(db.feedback || []);
    });
});

// Обработчик для добавления отзыва
app.post('/feedback', (req, res) => {
    const { text, username } = req.body; // Добавляем имя пользователя из запроса

    fs.readFile('data/db.json', 'utf8', (err, data) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Ошибка чтения базы данных');
        }

        const db = JSON.parse(data);

        const newFeedback = {
            id: db.feedback ? db.feedback.length + 1 : 1, // Простое добавление ID
            text,
            username: username // Добавляем имя пользователя из запроса
        };

        db.feedback = db.feedback || [];
        db.feedback.push(newFeedback);

        fs.writeFile('data/db.json', JSON.stringify(db, null, 2), err => {
            if (err) {
                console.error(err);
                return res.status(500).send('Ошибка записи в базу данных');
            }

            console.log('Новый отзыв добавлен:', newFeedback);
            res.status(201).json(newFeedback);
        });
    });
});

// Обработчик для удаления отзыва
app.delete('/feedback/:id', (req, res) => {
    const id = parseInt(req.params.id);

    fs.readFile('data/db.json', 'utf8', (err, data) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Ошибка чтения базы данных');
        }

        const db = JSON.parse(data);

        const feedbackIndex = db.feedback.findIndex(feedback => feedback.id === id);

        if (feedbackIndex === -1) {
            return res.status(404).send('Отзыв не найден');
        }

        db.feedback.splice(feedbackIndex, 1);

        fs.writeFile('data/db.json', JSON.stringify(db, null, 2), err => {
            if (err) {
                console.error(err);
                return res.status(500).send('Ошибка записи в базу данных');
            }

            console.log(`Отзыв с ID ${id} удален`);
            res.status(204).send();
        });
    });
});

// Обработчик для обновления профиля
app.put('/profile', (req, res) => {
    const { username, password } = req.body;
    console.log('Запрос на обновление профиля получен:', username, password); // Отладочный вывод

    fs.readFile('data/db.json', 'utf8', (err, data) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Ошибка чтения базы данных');
        }

        const db = JSON.parse(data);
        const userIndex = db.users.findIndex(user => user.username === username);

        if (userIndex === -1) {
            console.log("Пользователь не найден в базе данных"); // Отладочный вывод
            return res.status(404).send('Пользователь не найден');
        }

        // Обновляем данные пользователя
        db.users[userIndex].username = username;
        db.users[userIndex].password = password; // ВНИМАНИЕ: В РЕАЛЬНОМ ПРИЛОЖЕНИИ ПАРОЛЬ НУЖНО ХЕШИРОВАТЬ!

        fs.writeFile('data/db.json', JSON.stringify(db, null, 2), err => {
            if (err) {
                console.error(err);
                return res.status(500).send('Ошибка записи в базу данных');
            }

            console.log('Профиль пользователя обновлен:', db.users[userIndex]);
            res.json(db.users[userIndex]);
        });
    });
});

// Вывод всех определенных маршрутов
const endpoints = listEndpoints(app); // Получаем список маршрутов

console.log("Зарегистрированные маршруты:"); 
endpoints.forEach(endpoint => { 
    console.log(`${endpoint.methods.join(', ')}: ${endpoint.path}`);
});

app.listen(port, () => {
    console.log(`Сервер запущен на порту ${port}`);
});