import React from 'react';

function FeedbackList({ feedbacks, onDelete, token }) {
    if (!feedbacks) {
        return <p>Загрузка отзывов...</p>; // Сообщение о загрузке
    }

    if (!Array.isArray(feedbacks)) {
        return <p>Ошибка: Неверный формат данных с сервера.</p>; // Сообщение об ошибке
    }

    return (
        <ul>
            {feedbacks.length === 0 ? (
                <li>Нет отзывов для отображения.</li> // Сообщение, если нет отзывов
            ) : (
                feedbacks.map(feedback => (
                    <li key={feedback.id}>
                        <strong>{feedback.username}:</strong> {feedback.text}
                        <button onClick={() => onDelete(feedback.id)}>Удалить</button>
                    </li>
                ))
            )}
        </ul>
    );
}

export default FeedbackList;