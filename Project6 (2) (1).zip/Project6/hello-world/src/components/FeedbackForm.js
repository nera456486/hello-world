import React, { useState } from 'react';

function FeedbackForm({ onSubmit, token, username }) {
    const [text, setText] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();

        const newFeedback = {
            text: text,
            username: username // Передаем имя пользователя
        };

        fetch('http://localhost:3001/feedback', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(newFeedback)
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Ошибка при отправке отзыва');
                }
                return response.json();
            })
            .then(data => {
                onSubmit(data);
                setText('');
            })
            .catch(error => console.error('Ошибка:', error));
    };

    return (
        <form onSubmit={handleSubmit}>
            <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Оставьте свой отзыв"
            />
            <button type="submit">Отправить</button>
        </form>
    );
}

export default FeedbackForm;