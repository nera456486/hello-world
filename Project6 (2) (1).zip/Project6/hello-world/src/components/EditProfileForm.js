import React, { useState } from 'react';
import '../styles/global.css'; // Импортируйте общие стили
import axios from 'axios'; // Импортируем axios

function EditProfileForm({ username: initialUsername, onUpdate }) {
    const [username, setUsername] = useState(initialUsername);
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [message, setMessage] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (password !== confirmPassword) {
            setMessage('Пароли не совпадают');
            return;
        }

        console.log("Отправка запроса на обновление профиля:", { username, password }); // Отладочный вывод
        try {
            const response = await axios.put('http://localhost:3001/profile', { // Используем axios
                username,
                password,
            });

            console.log("Ответ от сервера:", response); // Отладочный вывод
            setMessage('Профиль успешно обновлен!');
            onUpdate(username); // Уведомляем родительский компонент об обновлении имени пользователя
        } catch (error) {
            console.error('Ошибка:', error);
            setMessage(`Ошибка: ${error.message}`);
            if (error.response) {
                console.error('Ответ сервера:', error.response.data); // Отладочный вывод для подробностей об ошибке
            }
        }
    };

    return (
        <form onSubmit={handleSubmit} className="form edit-profile-form">
            <h2>Редактировать профиль</h2>
            {message && <p>{message}</p>}
            <input
                type="text"
                placeholder="Имя пользователя"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="input"
            />
            <input
                type="password"
                placeholder="Новый пароль"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="input"
            />
            <input
                type="password"
                placeholder="Подтвердите новый пароль"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="input"
            />
            <button type="submit" className="button">Обновить профиль</button>
        </form>
    );
}

export default EditProfileForm;