import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import FeedbackForm from './FeedbackForm';
import FeedbackList from './FeedbackList';
import EditProfileForm from './EditProfileForm';
import '../styles/global.css';
import './HomePage.css';

function HomePage({ token, username, onUsernameUpdate }) {
    const [feedbacks, setFeedbacks] = useState(null);
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    const [currentUsername, setCurrentUsername] = useState(username);

    useEffect(() => {
        if (!token) {
            navigate('/login');
            return;
        }

        fetch('http://localhost:3001/feedback', {
            method: 'GET',
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Ошибка при загрузке отзывов');
                }
                return response.json();
            })
            .then(data => {
                setFeedbacks(data);
                setError(null);
            })
            .catch(err => {
                console.error('Ошибка:', err);
                setError(err.message);
                setFeedbacks(null);
            });
    }, [token, navigate]);

    const handleFeedbackSubmit = (newFeedback) => {
        setFeedbacks(prevFeedbacks => [...(prevFeedbacks || []), newFeedback]);
    };

    const handleDeleteFeedback = (id) => {
        fetch(`http://localhost:3001/feedback/${id}`, {
            method: 'DELETE',
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Ошибка при удалении отзыва');
                }
                setFeedbacks(prevFeedbacks => (prevFeedbacks || []).filter(feedback => feedback.id !== id));
            })
            .catch(error => console.error('Ошибка:', error));
    };

    const handleProfileUpdate = (newUsername) => {
        setCurrentUsername(newUsername);
        onUsernameUpdate(newUsername); // Вызываем функцию для обновления имени пользователя в App.js
        localStorage.setItem('username', newUsername);
    };

    return (
        <div className="home-page">
            <h2>Главная страница</h2>
            <EditProfileForm username={currentUsername} onUpdate={handleProfileUpdate} />
            {error && <p style={{ color: 'red' }}>Ошибка: {error}</p>}
            <FeedbackForm onSubmit={handleFeedbackSubmit} token={token} username={currentUsername} />
            <FeedbackList feedbacks={feedbacks} onDelete={handleDeleteFeedback} token={token} />
        </div>
    );
}

export default HomePage;