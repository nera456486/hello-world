import React, { useState, useEffect } from 'react';

function ProfileEditForm({ userId }) {
  const [userData, setUserData] = useState({
    username: '',
    email: '',
    bio: ''
  });

  useEffect(() => {
    // Загрузка данных пользователя при монтировании компонента
    fetch(`http://localhost:3001/users/${userId}`) // Замените на ваш URL и ID пользователя
      .then(response => {
        if (!response.ok) {
          throw new Error('Ошибка при загрузке данных пользователя');
        }
        return response.json();
      })
      .then(data => {
        setUserData(data);
      })
      .catch(error => {
        console.error('Ошибка:', error);
        alert('Не удалось загрузить данные пользователя');
      });
  }, [userId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData(prevData => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Отправка данных на сервер (замените на ваш URL)
    fetch(`http://localhost:3001/users/${userId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(userData)
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Ошибка при обновлении профиля');
      }
      return response.json();
    })
    .then(data => {
      // Обработка успешного обновления профиля
      console.log('Профиль успешно обновлен:', data);
      alert('Профиль успешно обновлен!');
    })
    .catch(error => {
      console.error('Ошибка:', error);
      alert('Ошибка при обновлении профиля');
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Редактирование профиля</h2>
      <div>
        <label htmlFor="username">Имя пользователя:</label>
        <input
          type="text"
          id="username"
          name="username"
          value={userData.username}
          onChange={handleChange}
        />
      </div>
      <div>
        <label htmlFor="email">Email:</label>
        <input
          type="email"
          id="email"
          name="email"
          value={userData.email}
          onChange={handleChange}
        />
      </div>
      <div>
        <label htmlFor="bio">Биография:</label>
        <textarea
          id="bio"
          name="bio"
          value={userData.bio}
          onChange={handleChange}
        />
      </div>
      <button type="submit">Сохранить</button>
    </form>
  );
}

export default ProfileEditForm;